window.sr = ScrollReveal({
	reset: true,
	duration: 700
});
sr.reveal('.reveal');